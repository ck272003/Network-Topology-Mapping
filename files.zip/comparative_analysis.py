# Comparative Analysis Framework
# Network Topology Discovery Methods Evaluation

import json
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

class DiscoveryMethodComparator:
    """
    Comparative analysis framework for evaluating network topology discovery methods.
    Compares DNAC API-based, SNMP/LLDP protocol-based, and ARP reachability-based approaches.
    """
    
    def __init__(self):
        self.methods = {
            'DNAC': {'layer': 'Enterprise/Managed', 'type': 'API-Based'},
            'SNMP_LLDP': {'layer': 'Vendor-Neutral', 'type': 'Protocol-Based'},
            'ARP': {'layer': 'Unmanaged', 'type': 'Reachability-Based'}
        }
        self.results = {}
        self.metrics = {}
        
    def collect_discovery_results(self, method: str, results: Dict) -> None:
        """
        Store discovery results for a specific method.
        
        Args:
            method: Discovery method name ('DNAC', 'SNMP_LLDP', 'ARP')
            results: Dictionary containing discovery results
        """
        self.results[method] = {
            'timestamp': datetime.now().isoformat(),
            'nodes': results.get('nodes', []),
            'links': results.get('links', []),
            'metadata': results.get('metadata', {}),
            'discovery_time': results.get('discovery_time', 0),
            'errors': results.get('errors', [])
        }
        
    def calculate_completeness_metrics(self, method: str, ground_truth: Dict = None) -> Dict:
        """
        Calculate completeness metrics for a discovery method.
        
        Metrics:
        - Node Discovery Rate: Percentage of actual devices discovered
        - Link Discovery Rate: Percentage of actual connections discovered
        - Metadata Completeness: Richness of device information
        
        Args:
            method: Discovery method name
            ground_truth: Optional reference topology for validation
            
        Returns:
            Dictionary of completeness metrics
        """
        if method not in self.results:
            return {}
            
        result = self.results[method]
        nodes_discovered = len(result['nodes'])
        links_discovered = len(result['links'])
        
        metrics = {
            'nodes_discovered': nodes_discovered,
            'links_discovered': links_discovered,
            'node_discovery_rate': None,
            'link_discovery_rate': None,
            'metadata_completeness': self._calculate_metadata_richness(result)
        }
        
        # If ground truth provided, calculate discovery rates
        if ground_truth:
            actual_nodes = ground_truth.get('nodes', 0)
            actual_links = ground_truth.get('links', 0)
            
            if actual_nodes > 0:
                metrics['node_discovery_rate'] = (nodes_discovered / actual_nodes) * 100
            if actual_links > 0:
                metrics['link_discovery_rate'] = (links_discovered / actual_links) * 100
                
        return metrics
    
    def _calculate_metadata_richness(self, result: Dict) -> float:
        """
        Calculate metadata richness score (0-100) based on available device information.
        
        Scoring:
        - Hostname/Device ID: 20 points
        - IP Address: 20 points
        - Device Type/Role: 15 points
        - MAC Address: 10 points
        - Management Status: 15 points
        - Additional attributes: 20 points (model, serial, location, etc.)
        """
        if not result['nodes']:
            return 0.0
            
        total_score = 0
        attribute_weights = {
            'hostname': 20, 'device_id': 20, 'name': 20,
            'ip_address': 20, 'management_ip': 20,
            'device_type': 15, 'role': 15, 'family': 15,
            'mac_address': 10,
            'management_status': 15, 'reachability': 15,
            'model': 5, 'serial_number': 5, 'location': 5, 'platform': 5
        }
        
        # Sample first node for metadata assessment
        sample_node = result['nodes'][0]
        for attr, weight in attribute_weights.items():
            if attr in sample_node and sample_node[attr]:
                total_score += weight
                
        return min(total_score, 100)  # Cap at 100
    
    def calculate_performance_metrics(self, method: str) -> Dict:
        """
        Calculate performance metrics.
        
        Metrics:
        - Discovery Time: Total time taken for topology discovery
        - Devices per Second: Discovery throughput
        - Success Rate: Percentage of successful operations
        
        Args:
            method: Discovery method name
            
        Returns:
            Dictionary of performance metrics
        """
        if method not in self.results:
            return {}
            
        result = self.results[method]
        discovery_time = result['discovery_time']
        nodes_discovered = len(result['nodes'])
        errors = len(result['errors'])
        
        total_operations = nodes_discovered + errors
        success_rate = (nodes_discovered / total_operations * 100) if total_operations > 0 else 0
        
        return {
            'discovery_time_seconds': discovery_time,
            'devices_per_second': nodes_discovered / discovery_time if discovery_time > 0 else 0,
            'success_rate_percent': success_rate,
            'error_count': errors
        }
    
    def calculate_granularity_score(self, method: str) -> Dict:
        """
        Calculate information granularity score.
        
        Evaluates the level of detail provided by each method:
        - Physical Topology: Device interconnections
        - Logical Topology: IP/routing information
        - Device Attributes: Hardware/software details
        - Network Hierarchy: Site/group organization
        
        Args:
            method: Discovery method name
            
        Returns:
            Dictionary with granularity scores (0-100 per category)
        """
        if method not in self.results:
            return {}
            
        result = self.results[method]
        scores = {
            'physical_topology': 0,
            'logical_topology': 0,
            'device_attributes': 0,
            'network_hierarchy': 0
        }
        
        # Physical topology: Based on link information
        if result['links']:
            link_detail = result['links'][0] if result['links'] else {}
            scores['physical_topology'] = 100 if link_detail.get('source') and link_detail.get('target') else 50
        
        # Logical topology: Based on IP addressing
        if result['nodes']:
            node = result['nodes'][0]
            has_ip = 'ip_address' in node or 'management_ip' in node
            scores['logical_topology'] = 100 if has_ip else 0
        
        # Device attributes: Use metadata richness
        scores['device_attributes'] = self._calculate_metadata_richness(result)
        
        # Network hierarchy: Check for site/group information
        if result['metadata'].get('site_hierarchy') or result['metadata'].get('groups'):
            scores['network_hierarchy'] = 100
        
        return scores
    
    def generate_comparison_matrix(self) -> pd.DataFrame:
        """
        Generate comprehensive comparison matrix of all methods.
        
        Returns:
            Pandas DataFrame with comparative metrics
        """
        comparison_data = []
        
        for method in self.methods.keys():
            if method not in self.results:
                continue
                
            completeness = self.calculate_completeness_metrics(method)
            performance = self.calculate_performance_metrics(method)
            granularity = self.calculate_granularity_score(method)
            
            row = {
                'Method': method,
                'Layer': self.methods[method]['layer'],
                'Type': self.methods[method]['type'],
                'Nodes Discovered': completeness.get('nodes_discovered', 0),
                'Links Discovered': completeness.get('links_discovered', 0),
                'Metadata Richness (%)': round(completeness.get('metadata_completeness', 0), 2),
                'Discovery Time (s)': round(performance.get('discovery_time_seconds', 0), 2),
                'Success Rate (%)': round(performance.get('success_rate_percent', 0), 2),
                'Physical Topology (%)': round(granularity.get('physical_topology', 0), 2),
                'Logical Topology (%)': round(granularity.get('logical_topology', 0), 2),
                'Device Attributes (%)': round(granularity.get('device_attributes', 0), 2)
            }
            comparison_data.append(row)
        
        return pd.DataFrame(comparison_data)
    
    def evaluate_applicability(self, method: str) -> Dict:
        """
        Evaluate applicability and constraints of each method.
        
        Returns:
            Dictionary describing method applicability
        """
        applicability_matrix = {
            'DNAC': {
                'network_types': ['Enterprise Data Center', 'Campus Network', 'Managed WAN'],
                'requirements': [
                    'Cisco DNA Center deployment',
                    'Device management via DNAC',
                    'API authentication credentials',
                    'Network reachability to DNAC'
                ],
                'advantages': [
                    'Complete topology visibility',
                    'Rich device metadata',
                    'Hierarchical site mapping',
                    'Integration with network assurance'
                ],
                'limitations': [
                    'Cisco ecosystem dependency',
                    'Requires DNAC licensing',
                    'Only discovers managed devices',
                    'API rate limiting'
                ],
                'scalability': 'High (thousands of devices)',
                'vendor_lock_in': 'High'
            },
            'SNMP_LLDP': {
                'network_types': ['Enterprise Network', 'Data Center', 'Service Provider'],
                'requirements': [
                    'SNMP enabled on devices',
                    'LLDP/CDP neighbor discovery enabled',
                    'SNMP community strings or SNMPv3 credentials',
                    'Direct network access to devices'
                ],
                'advantages': [
                    'Vendor-neutral protocol',
                    'Works across multi-vendor environments',
                    'Standard-based approach',
                    'Low overhead'
                ],
                'limitations': [
                    'Requires protocol support on devices',
                    'SNMP security concerns (v1/v2c)',
                    'Limited to directly connected neighbors',
                    'No topology hierarchy'
                ],
                'scalability': 'Medium (hundreds of devices)',
                'vendor_lock_in': 'Low'
            },
            'ARP': {
                'network_types': ['Home Network', 'Mobile Hotspot', 'Small Office', 'Unmanaged WiFi'],
                'requirements': [
                    'Layer 2 connectivity',
                    'IP subnet access',
                    'No authentication required'
                ],
                'advantages': [
                    'Works on any IP network',
                    'No device configuration needed',
                    'Simple implementation',
                    'No authentication required'
                ],
                'limitations': [
                    'Cannot discover true topology',
                    'Proxy ARP interference',
                    'Only shows reachability',
                    'No device metadata',
                    'Broadcast domain limited'
                ],
                'scalability': 'Low (subnet-limited)',
                'vendor_lock_in': 'None'
            }
        }
        
        return applicability_matrix.get(method, {})
    
    def generate_decision_framework(self) -> Dict:
        """
        Generate decision framework for selecting appropriate discovery method.
        
        Returns:
            Decision tree structure
        """
        return {
            'decision_tree': {
                'question_1': {
                    'question': 'Do you have access to a network management platform (e.g., Cisco DNAC)?',
                    'yes': {
                        'recommendation': 'DNAC',
                        'rationale': 'API-based discovery provides most comprehensive topology and metadata',
                        'use_cases': ['Enterprise topology mapping', 'Network documentation', 'Change impact analysis']
                    },
                    'no': 'question_2'
                },
                'question_2': {
                    'question': 'Are devices SNMP-enabled with LLDP/CDP support?',
                    'yes': {
                        'recommendation': 'SNMP_LLDP',
                        'rationale': 'Protocol-based discovery works across vendors and provides neighbor relationships',
                        'use_cases': ['Multi-vendor topology', 'Layer 2 connectivity mapping', 'Neighbor verification']
                    },
                    'no': 'question_3'
                },
                'question_3': {
                    'question': 'Do you only need basic device reachability?',
                    'yes': {
                        'recommendation': 'ARP',
                        'rationale': 'Reachability scan shows what devices are present on the network segment',
                        'use_cases': ['Device inventory', 'Reachability testing', 'Unmanaged network scanning'],
                        'caveat': 'Cannot determine actual topology structure'
                    },
                    'no': {
                        'recommendation': 'Hybrid Approach',
                        'rationale': 'Combine multiple methods for comprehensive visibility',
                        'use_cases': ['Complex multi-tier networks', 'Partial management scenarios']
                    }
                }
            },
            'selection_criteria': {
                'topology_accuracy_priority': 'DNAC > SNMP_LLDP > ARP',
                'vendor_neutrality_priority': 'SNMP_LLDP > ARP > DNAC',
                'ease_of_deployment_priority': 'ARP > SNMP_LLDP > DNAC',
                'metadata_richness_priority': 'DNAC > SNMP_LLDP > ARP',
                'cost_effectiveness_priority': 'ARP > SNMP_LLDP > DNAC'
            }
        }
    
    def export_results(self, filename: str = 'comparison_results.json') -> None:
        """Export all comparison results to JSON file."""
        output = {
            'timestamp': datetime.now().isoformat(),
            'methods': self.methods,
            'results': self.results,
            'comparison_matrix': self.generate_comparison_matrix().to_dict('records'),
            'decision_framework': self.generate_decision_framework()
        }
        
        with open(filename, 'w') as f:
            json.dump(output, f, indent=2, default=str)
        
        print(f"Results exported to {filename}")


# Example usage demonstration
if __name__ == "__main__":
    # Initialize comparator
    comparator = DiscoveryMethodComparator()
    
    # Simulate DNAC results
    dnac_results = {
        'nodes': [
            {'device_id': 'switch-1', 'hostname': 'core-sw-01', 'ip_address': '10.0.0.1', 
             'device_type': 'Cisco Catalyst 9300', 'role': 'CORE', 'management_status': 'Managed'},
            {'device_id': 'switch-2', 'hostname': 'dist-sw-01', 'ip_address': '10.0.0.2',
             'device_type': 'Cisco Catalyst 9300', 'role': 'DISTRIBUTION', 'management_status': 'Managed'}
        ],
        'links': [
            {'source': 'switch-1', 'target': 'switch-2', 'interface_source': 'Gi1/0/1', 'interface_target': 'Gi1/0/1'}
        ],
        'metadata': {'site_hierarchy': 'Global/USA/California/San Jose'},
        'discovery_time': 5.2,
        'errors': []
    }
    
    # Simulate SNMP results
    snmp_results = {
        'nodes': [
            {'hostname': 'device-1', 'ip_address': '192.168.1.1', 'mac_address': 'aa:bb:cc:dd:ee:ff'},
            {'hostname': 'device-2', 'ip_address': '192.168.1.2', 'mac_address': 'aa:bb:cc:dd:ee:01'}
        ],
        'links': [
            {'source': 'device-1', 'target': 'device-2'}
        ],
        'metadata': {},
        'discovery_time': 8.7,
        'errors': ['Timeout on device-3']
    }
    
    # Simulate ARP results
    arp_results = {
        'nodes': [
            {'ip_address': '192.168.43.1', 'mac_address': '00:11:22:33:44:55'},
            {'ip_address': '192.168.43.100', 'mac_address': '00:11:22:33:44:55'},  # Proxy ARP - same MAC
            {'ip_address': '192.168.43.101', 'mac_address': '00:11:22:33:44:55'}   # Proxy ARP - same MAC
        ],
        'links': [],  # Cannot determine links with ARP
        'metadata': {},
        'discovery_time': 12.3,
        'errors': []
    }
    
    # Collect results
    comparator.collect_discovery_results('DNAC', dnac_results)
    comparator.collect_discovery_results('SNMP_LLDP', snmp_results)
    comparator.collect_discovery_results('ARP', arp_results)
    
    # Generate comparison matrix
    comparison_df = comparator.generate_comparison_matrix()
    print("\n=== Comparison Matrix ===")
    print(comparison_df.to_string(index=False))
    
    # Get decision framework
    framework = comparator.generate_decision_framework()
    print("\n=== Decision Framework ===")
    print(json.dumps(framework, indent=2))
    
    # Export results
    comparator.export_results('/home/claude/comparison_results.json')
