# Research Methodology: Automated Network Topology Discovery and Analysis

## 1. Research Problem Statement

**Title:** Comparative Analysis of Network Topology Discovery Methods Under Varying Network Visibility Conditions

**Problem Context:**
Network topology discovery is critical for network management, troubleshooting, and security analysis. However, the effectiveness of discovery methods varies significantly based on network architecture, device management capabilities, and visibility constraints. This research investigates how different discovery approaches perform across enterprise-managed, vendor-neutral, and unmanaged network environments.

**Research Question:**
How do different network topology discovery methods (API-based, protocol-based, and reachability-based) differ in accuracy, completeness, and applicability across varying levels of network visibility and device management?

## 2. Research Objectives

### Primary Objectives:
1. Implement and evaluate three distinct network topology discovery approaches
2. Quantify the completeness and accuracy of each discovery method
3. Identify constraints and applicability boundaries for each approach
4. Develop a decision framework for selecting appropriate discovery methods

### Secondary Objectives:
1. Demonstrate practical implementation using industry-standard tools
2. Analyze protocol-level interactions and limitations
3. Document edge cases and failure modes in topology discovery

## 3. Research Methodology

### 3.1 Research Type
**Mixed Methods Approach:**
- **Experimental Research:** Implementing and testing different discovery methods
- **Comparative Analysis:** Evaluating methods across multiple dimensions
- **Case Study:** Real-world application using Cisco DNAC Sandbox

### 3.2 Experimental Design

#### Layer 1: Enterprise/Managed Network Discovery
**Method:** API-Based Discovery (Cisco DNA Center)
**Environment:** Cisco DevNet DNAC Sandbox
**Data Collection:**
- Device inventory (switches, routers, access points)
- Physical topology (nodes and links)
- Device capabilities and management status
- Network hierarchy and site topology

**Variables:**
- Independent: API endpoints, query parameters
- Dependent: Discovery completeness, API response time, data granularity
- Control: Sandbox environment consistency, authentication method

#### Layer 2: Vendor-Neutral Discovery
**Method:** Protocol-Based Discovery (SNMP + LLDP)
**Environment:** Enterprise managed devices with SNMP enabled
**Data Collection:**
- LLDP neighbor tables
- Device system information
- Interface status and connections

**Variables:**
- Independent: SNMP version, community strings, LLDP availability
- Dependent: Neighbor discovery success rate, protocol overhead
- Control: Device SNMP configuration, network reachability

#### Layer 3: Unmanaged Network Discovery
**Method:** Reachability-Based Discovery (ARP Scanning)
**Environment:** Mobile hotspot, consumer Wi-Fi networks
**Data Collection:**
- ARP table entries
- Reachable IP addresses
- MAC address mappings

**Variables:**
- Independent: Scan range, timeout values, packet rate
- Dependent: Device detection rate, proxy ARP behavior
- Control: Network subnet, scanning device position

### 3.3 Data Collection Methods

1. **Automated Script Execution**
   - Python scripts for each discovery layer
   - Structured logging and data capture
   - JSON/CSV output for analysis

2. **Network Metrics Collection**
   - Discovery time (seconds)
   - Node count (devices discovered)
   - Link count (connections identified)
   - Success rate (%)
   - Error/exception logs

3. **Qualitative Observations**
   - Protocol behavior patterns
   - Limitation documentation
   - Edge case identification

### 3.4 Evaluation Metrics

| Metric Category | Specific Metrics | Measurement Method |
|----------------|------------------|-------------------|
| **Completeness** | Node Discovery Rate, Link Discovery Rate | (Discovered / Actual) × 100% |
| **Accuracy** | False Positive Rate, False Negative Rate | Manual verification vs automated |
| **Performance** | Discovery Time, API/Protocol Overhead | Time measurement, packet analysis |
| **Scalability** | Devices per Second, Max Network Size | Extrapolation from test results |
| **Reliability** | Success Rate, Error Frequency | Multiple test runs, exception logging |
| **Granularity** | Topology Detail Level, Metadata Richness | Feature count, attribute depth |

### 3.5 Comparison Framework

#### Dimension 1: Network Visibility Requirements
- **Full Visibility:** Requires management plane access (DNAC)
- **Partial Visibility:** Requires protocol support (SNMP/LLDP)
- **Minimal Visibility:** Works with basic reachability (ARP)

#### Dimension 2: Information Richness
- **Physical Topology:** Device connections and hierarchy
- **Logical Topology:** IP addressing and routing relationships
- **Device Metadata:** Capabilities, models, firmware versions
- **Performance Data:** Interface statistics, utilization

#### Dimension 3: Operational Constraints
- **Authentication Required:** API keys, SNMP community strings
- **Protocol Dependencies:** LLDP, CDP, SNMP availability
- **Network Access:** Management VLAN, direct device access
- **Vendor Lock-in:** Proprietary vs open standards

## 4. Implementation Approach

### Phase 1: Environment Setup (Week 1)
- Configure DNAC Sandbox access
- Set up SNMP test environment
- Prepare ARP scanning network

### Phase 2: Development (Week 2-3)
- Implement DNAC discovery module
- Develop SNMP/LLDP discovery script
- Create ARP scanning tool
- Build unified visualization framework

### Phase 3: Data Collection (Week 4)
- Execute discovery scripts across all layers
- Collect performance metrics
- Document observations and edge cases

### Phase 4: Analysis (Week 5)
- Comparative analysis of methods
- Statistical evaluation of metrics
- Identification of patterns and limitations

### Phase 5: Documentation (Week 6)
- Research paper compilation
- Visualization creation
- Presentation preparation

## 5. Expected Outcomes

### Quantitative Outcomes:
1. Discovery completeness percentages for each method
2. Performance benchmarks (time, overhead)
3. Success rate statistics across network types

### Qualitative Outcomes:
1. Decision framework for method selection
2. Best practices for topology discovery
3. Identified limitations and workarounds
4. Future research directions

## 6. Limitations and Assumptions

### Assumptions:
- Cisco DNAC Sandbox accurately represents enterprise networks
- SNMP/LLDP are available on test devices
- ARP behavior in test networks represents typical consumer networks

### Limitations:
- Sandbox environment may not reflect all real-world constraints
- Limited access to physical enterprise infrastructure
- Proxy ARP behavior may vary across different network equipment
- Security policies may restrict certain discovery methods in production

## 7. Validation Approach

1. **Code Validation:** Unit tests, exception handling verification
2. **Data Validation:** Cross-reference with known network topologies
3. **Method Validation:** Compare results with network diagrams
4. **Peer Review:** Technical review of implementation and findings

## 8. Ethical Considerations

- All testing conducted on authorized networks (sandbox, personal hotspot)
- No scanning of unauthorized networks
- Compliance with network usage policies
- Responsible disclosure of any discovered vulnerabilities

## 9. Tools and Technologies

| Category | Tools/Libraries | Purpose |
|----------|----------------|---------|
| **Programming** | Python 3.8+ | Core implementation |
| **API Interaction** | requests, urllib3 | DNAC REST API calls |
| **Network Protocols** | pysnmp, scapy | SNMP queries, ARP scanning |
| **Graph Processing** | NetworkX | Topology graph construction |
| **Visualization** | Matplotlib, Plotly | Network visualization |
| **Data Analysis** | Pandas, NumPy | Metric calculation, analysis |
| **Documentation** | Markdown, Sphinx | Research documentation |

## 10. Timeline

| Week | Activities | Deliverables |
|------|-----------|--------------|
| 1 | Setup, Environment Configuration | Working test environments |
| 2-3 | Implementation, Development | Functional modules for all layers |
| 4 | Data Collection, Testing | Raw data, metrics logs |
| 5 | Analysis, Comparison | Comparative analysis report |
| 6 | Documentation, Presentation | Final research paper, presentation |

