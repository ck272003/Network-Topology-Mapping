"""
Advanced Visualization Module for Network Topology Discovery
Generates publication-quality visualizations for research analysis
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import networkx as nx
import numpy as np
import pandas as pd
import seaborn as sns
from typing import Dict, List, Tuple
import warnings
warnings.filterwarnings('ignore')

# Set publication-quality style
plt.style.use('seaborn-v0_8-paper')
sns.set_palette("husl")

class TopologyVisualizer:
    """
    Advanced visualization for network topology discovery research.
    Creates publication-ready figures for research documentation.
    """
    
    def __init__(self, figsize=(12, 8), dpi=300):
        self.figsize = figsize
        self.dpi = dpi
        self.colors = {
            'DNAC': '#1f77b4',      # Blue
            'SNMP_LLDP': '#ff7f0e', # Orange
            'ARP': '#2ca02c'        # Green
        }
        
    def visualize_topology_comparison(self, dnac_graph: nx.Graph, 
                                     snmp_graph: nx.Graph, 
                                     arp_data: Dict,
                                     save_path: str = '/home/claude/topology_comparison.png'):
        """
        Create side-by-side comparison of topologies from three methods.
        
        Args:
            dnac_graph: NetworkX graph from DNAC discovery
            snmp_graph: NetworkX graph from SNMP/LLDP discovery
            arp_data: Dictionary with ARP scan results
            save_path: Output file path
        """
        fig = plt.figure(figsize=(18, 6))
        
        # DNAC Topology
        ax1 = plt.subplot(131)
        self._draw_topology(dnac_graph, ax1, 'DNAC API-Based Discovery',
                          self.colors['DNAC'], show_labels=True)
        
        # SNMP/LLDP Topology
        ax2 = plt.subplot(132)
        self._draw_topology(snmp_graph, ax2, 'SNMP/LLDP Protocol-Based Discovery',
                          self.colors['SNMP_LLDP'], show_labels=True)
        
        # ARP Reachability Map
        ax3 = plt.subplot(133)
        self._draw_arp_reachability(arp_data, ax3, 'ARP Reachability Scan',
                                   self.colors['ARP'])
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        print(f"Topology comparison saved to {save_path}")
        plt.close()
    
    def _draw_topology(self, G: nx.Graph, ax, title: str, color: str, show_labels: bool = True):
        """Draw network topology graph with hierarchical layout."""
        if len(G.nodes()) == 0:
            ax.text(0.5, 0.5, 'No topology data', 
                   ha='center', va='center', fontsize=12, color='gray')
            ax.set_title(title, fontsize=14, fontweight='bold')
            ax.axis('off')
            return
        
        # Use spring layout for better visualization
        pos = nx.spring_layout(G, k=2, iterations=50, seed=42)
        
        # Draw edges
        nx.draw_networkx_edges(G, pos, ax=ax, edge_color='gray', 
                              width=2, alpha=0.6, arrows=True, 
                              arrowsize=20, arrowstyle='->')
        
        # Draw nodes
        node_sizes = [3000 if G.degree(node) > 2 else 2000 for node in G.nodes()]
        nx.draw_networkx_nodes(G, pos, ax=ax, node_color=color, 
                              node_size=node_sizes, alpha=0.9, 
                              edgecolors='white', linewidths=2)
        
        # Draw labels
        if show_labels:
            labels = {node: node.split('-')[-1] if '-' in str(node) else str(node)[:8] 
                     for node in G.nodes()}
            nx.draw_networkx_labels(G, pos, labels, ax=ax, font_size=9, 
                                   font_weight='bold', font_color='white')
        
        # Add statistics
        stats_text = f"Nodes: {G.number_of_nodes()}\nLinks: {G.number_of_edges()}"
        ax.text(0.02, 0.98, stats_text, transform=ax.transAxes,
               fontsize=10, verticalalignment='top',
               bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
        ax.axis('off')
    
    def _draw_arp_reachability(self, arp_data: Dict, ax, title: str, color: str):
        """
        Draw ARP reachability map showing proxy ARP behavior.
        Demonstrates that all IPs map to same MAC (gateway).
        """
        if not arp_data or 'nodes' not in arp_data or len(arp_data['nodes']) == 0:
            ax.text(0.5, 0.5, 'No ARP data', 
                   ha='center', va='center', fontsize=12, color='gray')
            ax.set_title(title, fontsize=14, fontweight='bold')
            ax.axis('off')
            return
        
        nodes = arp_data['nodes']
        
        # Group by MAC address to show proxy ARP
        mac_groups = {}
        for node in nodes:
            mac = node.get('mac_address', 'unknown')
            if mac not in mac_groups:
                mac_groups[mac] = []
            mac_groups[mac].append(node.get('ip_address', 'unknown'))
        
        # Create visualization
        # Central gateway node
        gateway_x, gateway_y = 0.5, 0.5
        circle = plt.Circle((gateway_x, gateway_y), 0.08, color=color, alpha=0.9, 
                           ec='white', linewidth=2, zorder=3)
        ax.add_patch(circle)
        ax.text(gateway_x, gateway_y, 'GW\n(Proxy ARP)', ha='center', va='center',
               fontsize=9, fontweight='bold', color='white', zorder=4)
        
        # Arrange IPs in circle around gateway
        num_ips = len(nodes)
        angles = np.linspace(0, 2*np.pi, num_ips, endpoint=False)
        radius = 0.35
        
        for i, (angle, node) in enumerate(zip(angles, nodes)):
            x = gateway_x + radius * np.cos(angle)
            y = gateway_y + radius * np.sin(angle)
            
            # Draw IP node
            circle = plt.Circle((x, y), 0.05, color='lightblue', alpha=0.7,
                               ec=color, linewidth=1.5, zorder=2)
            ax.add_patch(circle)
            
            ip = node.get('ip_address', 'unknown')
            # Shorten IP for display
            ip_short = ip.split('.')[-1] if '.' in ip else ip[:6]
            ax.text(x, y, ip_short, ha='center', va='center',
                   fontsize=7, zorder=3)
            
            # Draw dashed line to gateway (all through proxy ARP)
            ax.plot([x, gateway_x], [y, gateway_y], 'k--', 
                   alpha=0.3, linewidth=1, zorder=1)
        
        # Add explanation
        proxy_text = "All IPs map to single MAC\n(Gateway Proxy ARP)"
        ax.text(0.5, 0.05, proxy_text, ha='center', fontsize=9,
               style='italic', color='red',
               bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.3))
        
        stats_text = f"Devices: {len(nodes)}\nMAC addresses: {len(mac_groups)}"
        ax.text(0.02, 0.98, stats_text, transform=ax.transAxes,
               fontsize=10, verticalalignment='top',
               bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_aspect('equal')
        ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
        ax.axis('off')
    
    def create_comparison_bar_chart(self, comparison_df: pd.DataFrame,
                                    save_path: str = '/home/claude/comparison_metrics.png'):
        """
        Create grouped bar chart comparing key metrics across methods.
        
        Args:
            comparison_df: DataFrame from comparative_analysis module
            save_path: Output file path
        """
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        methods = comparison_df['Method'].tolist()
        x_pos = np.arange(len(methods))
        width = 0.6
        
        # Chart 1: Discovery Completeness
        ax1 = axes[0, 0]
        nodes = comparison_df['Nodes Discovered'].tolist()
        links = comparison_df['Links Discovered'].tolist()
        
        ax1.bar(x_pos - width/4, nodes, width/2, label='Nodes', 
               color=self.colors['DNAC'], alpha=0.8)
        ax1.bar(x_pos + width/4, links, width/2, label='Links',
               color=self.colors['SNMP_LLDP'], alpha=0.8)
        ax1.set_ylabel('Count', fontsize=11, fontweight='bold')
        ax1.set_title('Discovery Completeness', fontsize=12, fontweight='bold')
        ax1.set_xticks(x_pos)
        ax1.set_xticklabels(methods, rotation=15, ha='right')
        ax1.legend()
        ax1.grid(axis='y', alpha=0.3)
        
        # Chart 2: Information Richness
        ax2 = axes[0, 1]
        metadata = comparison_df['Metadata Richness (%)'].tolist()
        colors_bar = [self.colors[m] for m in methods]
        
        bars = ax2.bar(x_pos, metadata, width, color=colors_bar, alpha=0.8)
        ax2.set_ylabel('Richness Score (%)', fontsize=11, fontweight='bold')
        ax2.set_title('Metadata Richness', fontsize=12, fontweight='bold')
        ax2.set_xticks(x_pos)
        ax2.set_xticklabels(methods, rotation=15, ha='right')
        ax2.set_ylim(0, 110)
        
        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'{height:.1f}%', ha='center', va='bottom', fontsize=9)
        ax2.grid(axis='y', alpha=0.3)
        
        # Chart 3: Performance Metrics
        ax3 = axes[1, 0]
        times = comparison_df['Discovery Time (s)'].tolist()
        success = comparison_df['Success Rate (%)'].tolist()
        
        ax3_twin = ax3.twinx()
        
        bars1 = ax3.bar(x_pos - width/4, times, width/2, 
                       label='Discovery Time', color='steelblue', alpha=0.8)
        bars2 = ax3_twin.bar(x_pos + width/4, success, width/2,
                            label='Success Rate', color='forestgreen', alpha=0.8)
        
        ax3.set_ylabel('Time (seconds)', fontsize=11, fontweight='bold', color='steelblue')
        ax3_twin.set_ylabel('Success Rate (%)', fontsize=11, fontweight='bold', color='forestgreen')
        ax3.set_title('Performance Comparison', fontsize=12, fontweight='bold')
        ax3.set_xticks(x_pos)
        ax3.set_xticklabels(methods, rotation=15, ha='right')
        ax3.tick_params(axis='y', labelcolor='steelblue')
        ax3_twin.tick_params(axis='y', labelcolor='forestgreen')
        ax3_twin.set_ylim(0, 110)
        
        # Combined legend
        lines1, labels1 = ax3.get_legend_handles_labels()
        lines2, labels2 = ax3_twin.get_legend_handles_labels()
        ax3.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
        ax3.grid(axis='y', alpha=0.3)
        
        # Chart 4: Topology Granularity
        ax4 = axes[1, 1]
        if 'Physical Topology (%)' in comparison_df.columns:
            physical = comparison_df['Physical Topology (%)'].tolist()
            logical = comparison_df['Logical Topology (%)'].tolist()
            attributes = comparison_df['Device Attributes (%)'].tolist()
            
            x = np.arange(len(methods))
            width_g = 0.25
            
            ax4.bar(x - width_g, physical, width_g, label='Physical Topology',
                   color='#1f77b4', alpha=0.8)
            ax4.bar(x, logical, width_g, label='Logical Topology',
                   color='#ff7f0e', alpha=0.8)
            ax4.bar(x + width_g, attributes, width_g, label='Device Attributes',
                   color='#2ca02c', alpha=0.8)
            
            ax4.set_ylabel('Granularity Score (%)', fontsize=11, fontweight='bold')
            ax4.set_title('Information Granularity', fontsize=12, fontweight='bold')
            ax4.set_xticks(x)
            ax4.set_xticklabels(methods, rotation=15, ha='right')
            ax4.set_ylim(0, 110)
            ax4.legend(loc='upper left', fontsize=9)
            ax4.grid(axis='y', alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        print(f"Comparison metrics saved to {save_path}")
        plt.close()
    
    def create_radar_chart(self, comparison_df: pd.DataFrame,
                          save_path: str = '/home/claude/method_radar.png'):
        """
        Create radar chart showing multi-dimensional comparison.
        
        Dimensions:
        - Completeness
        - Performance
        - Granularity
        - Ease of Use
        - Vendor Neutrality
        """
        fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
        
        # Define categories
        categories = ['Completeness', 'Performance', 'Metadata\nRichness', 
                     'Ease of\nDeployment', 'Vendor\nNeutrality']
        num_vars = len(categories)
        
        # Compute angles for each category
        angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
        angles += angles[:1]  # Complete the circle
        
        # Normalize scores to 0-100 scale
        methods = comparison_df['Method'].tolist()
        
        for i, method in enumerate(methods):
            row = comparison_df[comparison_df['Method'] == method].iloc[0]
            
            # Calculate normalized scores
            completeness = (row['Nodes Discovered'] / max(comparison_df['Nodes Discovered'])) * 100
            performance = row['Success Rate (%)']
            metadata = row['Metadata Richness (%)']
            
            # Manual scoring for qualitative metrics
            ease_scores = {'DNAC': 40, 'SNMP_LLDP': 70, 'ARP': 95}
            vendor_scores = {'DNAC': 20, 'SNMP_LLDP': 90, 'ARP': 100}
            
            ease = ease_scores.get(method, 50)
            vendor = vendor_scores.get(method, 50)
            
            values = [completeness, performance, metadata, ease, vendor]
            values += values[:1]  # Complete the circle
            
            # Plot
            ax.plot(angles, values, 'o-', linewidth=2, 
                   label=method, color=self.colors.get(method, 'gray'))
            ax.fill(angles, values, alpha=0.15, color=self.colors.get(method, 'gray'))
        
        # Set category labels
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(categories, fontsize=11)
        
        # Set y-axis
        ax.set_ylim(0, 100)
        ax.set_yticks([20, 40, 60, 80, 100])
        ax.set_yticklabels(['20', '40', '60', '80', '100'], fontsize=9, color='gray')
        ax.set_title('Multi-Dimensional Method Comparison', 
                    fontsize=14, fontweight='bold', pad=30)
        
        # Add legend
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=11)
        
        # Grid
        ax.grid(True, linestyle='--', alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        print(f"Radar chart saved to {save_path}")
        plt.close()
    
    def create_decision_flowchart(self, save_path: str = '/home/claude/decision_tree.png'):
        """
        Create visual decision tree for method selection.
        Uses matplotlib annotations and arrows.
        """
        fig, ax = plt.subplots(figsize=(14, 10))
        
        # Define positions for decision nodes
        positions = {
            'start': (0.5, 0.95),
            'q1': (0.5, 0.80),
            'q2': (0.3, 0.60),
            'q3': (0.15, 0.40),
            'dnac': (0.7, 0.60),
            'snmp': (0.45, 0.40),
            'arp': (0.15, 0.20),
            'hybrid': (0.3, 0.20)
        }
        
        # Draw nodes
        # Start
        self._draw_decision_box(ax, positions['start'], 
                               'Network Topology\nDiscovery Needed', 
                               'lightyellow', size=(0.18, 0.08))
        
        # Question 1
        self._draw_decision_box(ax, positions['q1'],
                               'Management\nPlatform Available?\n(e.g., Cisco DNAC)',
                               'lightblue', size=(0.2, 0.1))
        
        # Question 2
        self._draw_decision_box(ax, positions['q2'],
                               'SNMP/LLDP\nEnabled?',
                               'lightblue', size=(0.16, 0.08))
        
        # Question 3
        self._draw_decision_box(ax, positions['q3'],
                               'Only Need\nReachability?',
                               'lightblue', size=(0.14, 0.08))
        
        # Recommendations
        self._draw_decision_box(ax, positions['dnac'],
                               'USE: DNAC API\n\n✓ Complete topology\n✓ Rich metadata\n✓ Hierarchy',
                               'lightgreen', size=(0.18, 0.12))
        
        self._draw_decision_box(ax, positions['snmp'],
                               'USE: SNMP/LLDP\n\n✓ Vendor-neutral\n✓ Neighbor discovery\n✓ Standard protocols',
                               'lightgreen', size=(0.18, 0.12))
        
        self._draw_decision_box(ax, positions['arp'],
                               'USE: ARP Scan\n\n✓ No config needed\n✓ Works anywhere\n⚠ No topology',
                               'lightyellow', size=(0.16, 0.12))
        
        self._draw_decision_box(ax, positions['hybrid'],
                               'USE: Hybrid\n\nCombine multiple\nmethods',
                               'lightcoral', size=(0.14, 0.08))
        
        # Draw arrows
        arrow_props = dict(arrowstyle='->', lw=2, color='black')
        
        # Start to Q1
        ax.annotate('', xy=positions['q1'], xytext=positions['start'],
                   arrowprops=arrow_props)
        
        # Q1 to DNAC (YES)
        ax.annotate('', xy=positions['dnac'], xytext=positions['q1'],
                   arrowprops=dict(arrowstyle='->', lw=2, color='green'))
        ax.text(0.6, 0.70, 'YES', fontsize=10, color='green', fontweight='bold')
        
        # Q1 to Q2 (NO)
        ax.annotate('', xy=positions['q2'], xytext=positions['q1'],
                   arrowprops=dict(arrowstyle='->', lw=2, color='red'))
        ax.text(0.38, 0.70, 'NO', fontsize=10, color='red', fontweight='bold')
        
        # Q2 to SNMP (YES)
        ax.annotate('', xy=positions['snmp'], xytext=positions['q2'],
                   arrowprops=dict(arrowstyle='->', lw=2, color='green'))
        ax.text(0.36, 0.50, 'YES', fontsize=10, color='green', fontweight='bold')
        
        # Q2 to Q3 (NO)
        ax.annotate('', xy=positions['q3'], xytext=positions['q2'],
                   arrowprops=dict(arrowstyle='->', lw=2, color='red'))
        ax.text(0.20, 0.50, 'NO', fontsize=10, color='red', fontweight='bold')
        
        # Q3 to ARP (YES)
        ax.annotate('', xy=positions['arp'], xytext=positions['q3'],
                   arrowprops=dict(arrowstyle='->', lw=2, color='green'))
        ax.text(0.15, 0.30, 'YES', fontsize=10, color='green', fontweight='bold')
        
        # Q3 to Hybrid (NO)
        ax.annotate('', xy=positions['hybrid'], xytext=positions['q3'],
                   arrowprops=dict(arrowstyle='->', lw=2, color='red'))
        ax.text(0.21, 0.30, 'NO', fontsize=10, color='red', fontweight='bold')
        
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        ax.set_title('Network Discovery Method Selection Framework',
                    fontsize=16, fontweight='bold', pad=20)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        print(f"Decision flowchart saved to {save_path}")
        plt.close()
    
    def _draw_decision_box(self, ax, position: Tuple[float, float], 
                          text: str, color: str, size: Tuple[float, float] = (0.15, 0.08)):
        """Helper function to draw decision boxes."""
        x, y = position
        width, height = size
        
        rect = mpatches.FancyBboxPatch(
            (x - width/2, y - height/2), width, height,
            boxstyle="round,pad=0.01", 
            edgecolor='black', facecolor=color, 
            linewidth=2, alpha=0.8
        )
        ax.add_patch(rect)
        
        ax.text(x, y, text, ha='center', va='center',
               fontsize=9, fontweight='bold', wrap=True)


# Demonstration
if __name__ == "__main__":
    visualizer = TopologyVisualizer()
    
    # Create sample graphs
    dnac_graph = nx.Graph()
    dnac_graph.add_edges_from([
        ('core-sw-01', 'dist-sw-01'),
        ('core-sw-01', 'dist-sw-02'),
        ('dist-sw-01', 'access-sw-01'),
        ('dist-sw-01', 'access-sw-02'),
        ('dist-sw-02', 'access-sw-03')
    ])
    
    snmp_graph = nx.Graph()
    snmp_graph.add_edges_from([
        ('device-1', 'device-2'),
        ('device-2', 'device-3')
    ])
    
    arp_data = {
        'nodes': [
            {'ip_address': '192.168.43.1', 'mac_address': 'aa:bb:cc:dd:ee:ff'},
            {'ip_address': '192.168.43.100', 'mac_address': 'aa:bb:cc:dd:ee:ff'},
            {'ip_address': '192.168.43.101', 'mac_address': 'aa:bb:cc:dd:ee:ff'},
            {'ip_address': '192.168.43.102', 'mac_address': 'aa:bb:cc:dd:ee:ff'}
        ]
    }
    
    # Generate visualizations
    visualizer.visualize_topology_comparison(dnac_graph, snmp_graph, arp_data)
    
    # Sample comparison data
    comparison_data = {
        'Method': ['DNAC', 'SNMP_LLDP', 'ARP'],
        'Layer': ['Enterprise/Managed', 'Vendor-Neutral', 'Unmanaged'],
        'Type': ['API-Based', 'Protocol-Based', 'Reachability-Based'],
        'Nodes Discovered': [15, 8, 4],
        'Links Discovered': [18, 6, 0],
        'Metadata Richness (%)': [95, 55, 15],
        'Discovery Time (s)': [5.2, 8.7, 12.3],
        'Success Rate (%)': [100, 87.5, 100],
        'Physical Topology (%)': [100, 100, 0],
        'Logical Topology (%)': [100, 100, 100],
        'Device Attributes (%)': [95, 55, 15]
    }
    
    comparison_df = pd.DataFrame(comparison_data)
    
    visualizer.create_comparison_bar_chart(comparison_df)
    visualizer.create_radar_chart(comparison_df)
    visualizer.create_decision_flowchart()
    
    print("\nAll visualizations generated successfully!")
